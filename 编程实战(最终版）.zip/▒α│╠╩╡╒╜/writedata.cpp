#include"writedata.h" 
#include"studentinformation.h"
#include<fstream>
#include<iostream>
void write_file(CStudent *stu)
{
	ofstream out;
	out.open("data.txt");//���ļ�
	if (out.fail()) {
		cout << "���ܴ��ļ�" << endl;
	}
	else//д���ļ�
	{
		int first_subscript= 1;
		while (stu[first_subscript].getnumber() != 0)
		{
			first_subscript++;
		}
		for (int second_subscript = 0; second_subscript < first_subscript; second_subscript++)
		{
			if (stu[second_subscript].getname() == "��")
			{
				out << endl;
				continue;
			}
			out << stu[second_subscript].getnumber() << setw(5) << stu[second_subscript].getname() << setw(5) << stu[second_subscript].getsex() ;
			out<< setw(5) << stu[second_subscript].getage() << setw(5) << stu[second_subscript].getaddress() << setw(5) << stu[second_subscript].getmark();
			out << endl;
		}
		
		out.close();
	}
}
