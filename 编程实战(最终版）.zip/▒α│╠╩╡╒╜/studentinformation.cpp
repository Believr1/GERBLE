#include"studentinformation.h"

CStudent::CStudent(int nu,string na, string se, int ag, string ad, int ma) :
number(nu),name(na), sex(se), age(ag), address(ad), mark(ma){}
void CStudent::setstudent(int nu,string na, string se, int ag, string ad, int ma)
{
	number = nu;
	name = na;
	sex = se;
	age = ag;
	address = ad;
	mark = ma;
}
void CStudent::print()
{
	cout << number << setw(9) << name << setw(6) << sex << setw(6) << age << setw(6) << address << setw(6) << mark << endl;
}
