#ifndef _STUDENTINFORMATION_H_  
#define _STUDENTINFORMATION_H_
#pragma once
#include<iostream>
#include<fstream>
#include<string>
#include<iomanip>
using namespace std;
class CStudent//ѧ����Ϣ
{
protected:
	int number;//ѧ��
	string name;//����
	string sex;//�Ա�
	int age;//����
	string address;//��ַ
	int mark;//�ɼ�
	
public:
	CStudent() :number(0), name("����"), sex("��"), age(18), address("�ɶ�"), mark(90) {}
	CStudent(int nu,string na, string se, int ag, string ad, int ma);
	void setstudent(int nu,string na, string se, int ag, string ad, int ma);
	string getname() const { return name; }//�������
	string getsex() const { return sex; }//����Ա�
	int getage() const { return age; }//����Ա�
	string getaddress() const { return address; }//��õ�ַ
	int getmark() const { return mark; }//��÷���
	int getnumber() const { return number; }//���ѧ��
	void setname(string na) { name = na; }
	void setsex(string se) { sex = se; }
	void setage(int ag) { age = ag; }
	void setaddress(string ad) { address = ad; }
	void setmark(int ma) { mark = ma; }
	void print();
    void read(ifstream &p)
	{
		p >> number>>name>>sex>>age>>address>>mark;
	}
    
};
#endif 
