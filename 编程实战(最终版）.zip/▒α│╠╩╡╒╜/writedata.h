#pragma once
#ifndef _WRITEDATA_H_
#define _WRITEDATA_H_
#include"studentinformation.h"
#include<fstream>
#include<iostream>


void write_file(CStudent *stu);

#endif
