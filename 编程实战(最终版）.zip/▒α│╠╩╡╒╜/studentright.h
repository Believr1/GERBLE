#ifndef _STUDENTRIGHT_H_
#define _STUDENTRIGHT_H_
#include<iostream>
#include<iomanip>
#include<cstdlib>
#include"studentinformation.h"
#include<string>
#include"writedata.h"
int searchnumber2(CStudent *stu, const int num);
void studentright(CStudent *stu);

	
#endif


